import { useState } from 'react'
export default function Home() {
  const [status, setStatus] = useState('')
  async function handleSubmit(e) {
    e.preventDefault()
    setStatus('Sending...')
    const form = e.target
    const data = new FormData(form)
    const res = await fetch('https://formspree.io/f/mqagwodg', {
      method: 'POST',
      body: data,
      headers: {
        Accept: 'application/json'
      }
    })
    if (res.ok) {
      setStatus('Thank you! Your quote request has been sent.')
      form.reset()
    } else {
      setStatus('Oops! Something went wrong, please try again.')
    }
  }
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src="/VA-logo.png" alt="VA logo" className="h-12"/>
            <h1 className="text-2xl font-bold text-blue-700">VOLT-AMP AUTOMATION</h1>
          </div>
          <nav className="hidden md:flex gap-6 text-gray-700">
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#industries">Industries</a>
            <a href="#contact">Contact</a>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="bg-gradient-to-r from-blue-600 to-blue-400 text-white text-center py-16">
          <h2 className="text-4xl font-bold mb-4">Powering Precision, Driving Innovation</h2>
          <p className="max-w-2xl mx-auto">Delivering high-quality electrical design and control panel solutions engineered for industrial excellence.</p>
        </section>

        <section id="about" className="py-12 max-w-4xl mx-auto px-6">
          <h3 className="text-3xl font-bold text-center text-blue-600 mb-4">About Us</h3>
          <p className="text-center text-lg">At <strong>VOLTAMP AUTOMATION</strong>, we specialize in designing and manufacturing high-quality electrical control panels tailored for industrial applications. From design to commissioning, we deliver reliable, efficient, and industry-ready solutions.</p>
        </section>

        <section id="services" className="py-12 bg-gray-100">
          <h3 className="text-3xl font-bold text-center text-blue-600 mb-6">Our Expertise</h3>
          <div className="max-w-6xl mx-auto px-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {['MCC & PCC Panels','APFC Panels','PLC & HMI Panels','Drive (VFD) Panels','Star-Delta Starter Panels','Distribution Panels','Electrical Design & Documentation'].map((s,i)=>(
              <div key={i} className="p-6 bg-white rounded-lg shadow">
                <h4 className="font-semibold text-lg text-blue-700 mb-2">{s}</h4>
                <p className="text-gray-600">Professional design and assembly using premium components and industry standards.</p>
              </div>
            ))}
          </div>
        </section>

        <section id="industries" className="py-12 max-w-6xl mx-auto px-6">
          <h3 className="text-3xl font-bold text-center text-blue-600 mb-6">Industries We Serve</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {['Manufacturing Plants','HVAC & Building Automation','Machine OEMs','Food & Beverage','Water Treatment & Pumping','Automotive & Process Industries'].map((i)=>(
              <div key={i} className="p-4 bg-white rounded-lg shadow text-center">
                <h4 className="font-medium text-blue-700">{i}</h4>
              </div>
            ))}
          </div>
        </section>

        <section id="quote" className="py-12 bg-white border-t">
          <h3 className="text-3xl font-bold text-center text-blue-600 mb-4">Request a Quote</h3>
          <p className="text-center text-gray-600 mb-6">Fill out the form below and our team will get back to you shortly.</p>
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto grid gap-4 px-6" encType="multipart/form-data">
            <input name="name" type="text" required placeholder="Your name" className="border rounded p-3 w-full"/>
            <input name="email" type="email" required placeholder="Your email" className="border rounded p-3 w-full"/>
            <input name="phone" type="tel" required placeholder="Phone number" className="border rounded p-3 w-full"/>
            <textarea name="message" rows="4" required placeholder="Project details" className="border rounded p-3 w-full"></textarea>
            <input name="attachment" type="file" className="border rounded p-2 w-full"/>
            <button type="submit" className="bg-blue-600 text-white py-3 rounded">Send Request</button>
            {status && <p className="text-green-600 text-center">{status}</p>}
          </form>
        </section>

        <section id="contact" className="py-12 bg-blue-600 text-white text-center">
          <h3 className="text-2xl font-bold mb-2">Contact Us</h3>
          <p>VOLTAMP AUTOMATION — Kolhapur | Pune</p>
          <p className="mt-2">Email: voltampautomation@gmail.com | Phone: +91-9021596478</p>
        </section>
      </main>

      <footer className="bg-gray-900 text-gray-400 text-center py-6">
        <p>© {new Date().getFullYear()} VOLTAMP AUTOMATION. All Rights Reserved.</p>
      </footer>
    </div>
  )
}
